#include <iostream>
#include <string>
#include <vector>
using namespace std;

int longitud_desplegado(int n) {
    if (n == 1 || n == 0) {
        return 1;
    } else {
        return 2*longitud_desplegado(n/2) + 1;
    }
}

int contando_unos(int n, int l, int r) {
    if (n == 0) {
        return 0;
    }
    if (n == 1) {
        return 1;
    }

    int cantidad_unos = 0;
    int longitud_izquierda = longitud_desplegado(n/2);
    int longitud_total = (2 * longitud_izquierda) + 1;
    int posicion_media = longitud_izquierda + 1;
    
    if (r <= longitud_izquierda) {
         return contando_unos(n/2, l, r);
    }

    if (l > posicion_media) {
        return contando_unos(n/2, l - posicion_media, r - posicion_media);
    }

    if (l <= longitud_izquierda) {
        cantidad_unos += contando_unos(n/2, l, longitud_izquierda);
    }
    
    if (l <= posicion_media && posicion_media <= r) {
        cantidad_unos += (n % 2);
    }

    if (r > posicion_media) {
        cantidad_unos += contando_unos(n/2, 1, r - posicion_media);
    }

    return cantidad_unos;
}


int main() {
    int n, l, r;
    cin >> n >> l >> r;
    int resultado = contando_unos(n, l, r);
    cout << resultado << endl;
}